export const apiURL = 'http://localhost:5000'
export const adminEmail = [
    "lovelysen020@gmail.com",
]
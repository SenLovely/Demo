import { FETCH_CARDS, FETCH_CARD, FETCH_CARD_FILTER, UPDATE_CARD_COUNT, ADMIN_ADD_CARD, ADMIN_UPDATE_CARD} from '../actions/types';
const INITIAL_STATE = {
  giftCards: [],
  giftCardsFiltered: [],
  giftCard: {},
};

const giftsReducer = (state = INITIAL_STATE, action) => {
  switch (action.type) {

    case FETCH_CARD:
      console.log("giftsReducer",action.payload.data);
      state = { ...state, giftCard: action.payload.data }
      break;

    case FETCH_CARDS:
      const { cards, pageNo } = action.payload;
      if(pageNo > 1) {
        let updatedCards = state.giftCards.concat(cards);
        state = {
          ...state,
          giftCards: updatedCards
        };
      }
      else {
        state = {
          ...state,
          giftCards: cards
        };
      }
     
      break;

    case ADMIN_ADD_CARD:
      state = {
        ...state,
        giftCards: action.payload
      };
      break;
    
    case ADMIN_UPDATE_CARD:
      console.log(state)
     
     
        console.log("check data",action.payload.data,action.payload.data.id,state.giftCards)
        
          state = {
            ...state,
            giftCard: action.payload.data
          };
         
      
      console.log(state)
      break;

    case FETCH_CARD_FILTER:
      state = {
        ...state,
        giftCardsFiltered: []
      };
      state = {
        ...state,
        giftCardsFiltered: action.payload
      };
      break;
    
      case UPDATE_CARD_COUNT:
        state = { ...state, giftCard: action.payload }
        break;

    default:
      state = {
        ...state
      };
      break;
  }
  return state;
};

export default giftsReducer;

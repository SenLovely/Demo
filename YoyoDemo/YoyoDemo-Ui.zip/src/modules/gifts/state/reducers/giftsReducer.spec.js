import giftsReducer from "./giftsReducer";
import { FETCH_CARDS, FETCH_CARD, FETCH_CARD_FILTER, UPDATE_CARD_COUNT, ADMIN_ADD_CARD, ADMIN_UPDATE_CARD} from '../actions/types';

describe("Gift Reducer Test Suite", () => {
  it("should be initial state", () => {
    expect(giftsReducer(undefined, {})).toEqual(
    {
        giftCards: [],
        giftCardsFiltered: [],
        giftCard: {},
    });
  });
  
   
  it("should FETCH_CARD work and fetch the data", () => {
    const prevState = {
        giftCard: {}
    };
    const cardData = {
        cardCount: 15
    };

    let action = {
        type: FETCH_CARD,
        payload: {
            data: cardData
        }
    };

    expect(giftsReducer(prevState, action)).toEqual(
    {
        giftCard: cardData
    });
});

it("should ADMIN_UPDATE_CARD give updated data", () => {
    const prevState = {
        giftCard: {}
    };
    const cardData = {
        cardCount: 10
    };

    let action = {
        type: ADMIN_UPDATE_CARD,
        payload: {
            data: cardData
        }
    };

    expect(giftsReducer(prevState, action)).toEqual(
    {
        giftCard: cardData
    });
});

});
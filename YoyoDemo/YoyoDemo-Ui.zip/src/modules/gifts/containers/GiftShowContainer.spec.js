import React from 'react';
import {shallow} from 'enzyme';
import thunk from 'redux-thunk';
import configureStore from 'redux-mock-store';
import GiftShowContainer from './GiftShowContainer.js';


const middlewares = [thunk];
const createMockStore = configureStore(middlewares);

describe("GiftShowContainer Test Suite", () => {

    it("GiftShowContainer render", (done) => {
    
      const initialState = {login: {loginStatus: true},gifts:{giftcards:{}},users:{UserDetails:{}}};
  const store = createMockStore(initialState)
      const wrapper = shallow(<GiftShowContainer store={store} />);
  
      
      expect(wrapper.exists()).toBe(true);
      done();
    });
});
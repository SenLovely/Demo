import React,{useEffect, useState} from 'react';
import PropTypes from 'prop-types';
import { withStyles } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import { Button } from '@material-ui/core';
import {DateFormatter} from '../../common/components/DateFormatter';
import { InfiniteLoader } from "react-virtualized";
const styles = theme => ({
  root: {
    minHeight: '100vh',
    width: '100%',
    marginTop: theme.spacing.unit * 3,
    overflowX: 'auto',
  },
  table: {
    minWidth: 700,
  },
});

function GiftsReceived(props) {
  const { classes, data } = props;
  const [loadedData, setloadedData] = useState(100);
  useEffect(() => {
   console.log("gift load",loadedData);
  });
 const loadMoreRows = ({startIndex, stopIndex}) => {
    this.props.getDataFromServer({startIndex, stopIndex}).then( (result) => {
     var tempData = loadedData
     result.forEach(returnItem => {
      tempData.push(returnItem)
     })
     setloadedData({loadedData:tempData})
    })
   }
  const isRowLoaded = ({ index }) =>  {
    return !!loadedData[index];
   }
  return (
    <Paper className={classes.root}>
      
       <InfiniteLoader
     isRowLoaded={isRowLoaded}
     loadMoreRows={loadMoreRows}
     //rowCount={this.props.rowCount}
    >
     {({ onRowsRendered, registerChild }) => (
      <Table className={classes.table}>
        <TableHead>
          <TableRow>
            <TableCell>CARD NAME</TableCell>
            <TableCell>POINTS</TableCell>
            <TableCell>RECEIVED FROM</TableCell>
            <TableCell>CARD DESC</TableCell>
            <TableCell>ISSUE DATE</TableCell>
            <TableCell>EXPIRY DATE</TableCell>
            <TableCell>REDEEM</TableCell>
          </TableRow>
        </TableHead>
      
        <TableBody>
        
          {data.map(row => (
            <TableRow key={row.id}>
              <TableCell component="th" scope="row">
                {row.cardName}
              </TableCell>
              <TableCell>{row.cardPoints}</TableCell>
              <TableCell>{row.senderEmail}</TableCell>
              <TableCell>{row.cardShortDesc}</TableCell>
              <TableCell>{DateFormatter(row.cardIssueDate)}</TableCell>
              <TableCell>{DateFormatter(row.cardExpiryDate)}</TableCell>
              <TableCell>{row.isRedeemed ? 'Redeemed' : <Button variant="contained" color="primary" onClick={()=>props.redeemCard(row)}>Redeem</Button>}</TableCell>
            </TableRow>
          ))}

        </TableBody>
       
      </Table>
        )}
        </InfiniteLoader>
    </Paper>
  );
}

GiftsReceived.propTypes = {
  classes: PropTypes.object.isRequired,
};

export default withStyles(styles)(GiftsReceived);
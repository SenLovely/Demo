import { mount, shallow } from "enzyme";
import React from "react";
import { ProfileContainer } from "./profileContainers";
// import { LOGIN } from "../state/actions/types";

describe("Profile Container Test Suite", () => {
  it("should find a single button on render", () => {
    const detailsObject = {
      email: "amazon@gmail.com",
      firstName: "amazon",
      lastName: "ss",
      socialProfileLink: null,
      picture: null
    };
    const user = {
      balance_points: 1000
    }
    const wrapper = mount(<ProfileContainer 
      isLoggedIn={true}
      detailsObject={detailsObject}
      user={user}
      userDetails = {jest.fn()}
    />);
    
    expect(wrapper.find('div').length).toBe(8);
    expect(wrapper.find('label').length).toBe(3);
    expect(wrapper.find('div').at(5).text()).toBe(" ");
    expect(wrapper.find('div').at(6).text()).toBe('amazon@gmail.com');
    expect(wrapper.find('div').at(7).text()).toBe('1000 Points');
  });
  
  it('should render the expected HTML', () => {
    const detailsObject = {
      email: "amazon@gmail.com",
      firstName: "amazon",
      lastName: "ss",
      socialProfileLink: null,
      picture: null
    };
    const user = {
      balance_points: 1000
    }
    expect(shallow(<ProfileContainer 
      isLoggedIn={true}
      detailsObject={detailsObject}
      user={user}
      userDetails = {jest.fn()}
    />
    ).html()).toMatchSnapshot();
  });
});
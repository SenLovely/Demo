import React from "react";
import { mount } from "enzyme";

import { GiftsSendTableContainer, mapDispatchToProps } from "./GiftsSendTableContainer";

describe("Gifts Sent Table Test Suite", () => {


  it('table with header and data', () => {
    //Mocks
    const data = [
      {
        cardName: 'amazon',
        cardPoints: 100,
        senderEmail: 'amazon@gmail.com',
        cardIssueDate: "Sun May 19 2019 15:43:25 GMT+0530 (India Standard Time)",
        cardExpiryDate: "Sun May 19 2019 15:43:25 GMT+0530 (India Standard Time)"
      },
      {
        cardName: 'test1',
        cardPoints: 2,
        senderEmail: 'amazon@gmail.com',
        cardIssueDate: "Sun May 19 2019 15:43:25 GMT+0530 (India Standard Time)",
        cardExpiryDate: "Sun May 19 2019 15:43:25 GMT+0530 (India Standard Time)"
      },
      {
        cardName: 'test2',
        cardPoints: 3,
        senderEmail: 'amazon@gmail.com',
        cardIssueDate: "Sun May 19 2019 15:43:25 GMT+0530 (India Standard Time)",
        cardExpiryDate: "Sun May 19 2019 15:43:25 GMT+0530 (India Standard Time)"
      }
    ];

    const user = {
      email: "knowledge.com2k16@gmail.com"
    };

    const wrapper = mount(<GiftsSendTableContainer 
    isLoggedIn = {true}
    sentCards={data}
    user={user}
    fetchSentCards={jest.fn()}
    />);
    
    expect(wrapper.find('div').length).toBe(32);
  });

  it('should render the expected HTML', () => {
    expect(mount(<GiftsSendTableContainer 
    isLoggedIn = {true}
    sentCards={[]}
    fetchSentCards={jest.fn()}
    />
    ).html()).toMatchSnapshot();
  });

  it('should render the expected HTML', () => {
    //Mocks
    const data = [
      {
        cardName: 'amazon',
        cardPoints: 100,
        senderEmail: 'amazon@gmail.com',
        cardIssueDate: "Sun May 19 2019 15:43:25 GMT+0530 (India Standard Time)",
        cardExpiryDate: "Sun May 19 2019 15:43:25 GMT+0530 (India Standard Time)"
      },
      {
        cardName: 'test1',
        cardPoints: 2,
        senderEmail: 'amazon@gmail.com',
        cardIssueDate: "Sun May 19 2019 15:43:25 GMT+0530 (India Standard Time)",
        cardExpiryDate: "Sun May 19 2019 15:43:25 GMT+0530 (India Standard Time)"
      },
      {
        cardName: 'test2',
        cardPoints: 3,
        senderEmail: 'amazon@gmail.com',
        cardIssueDate: "Sun May 19 2019 15:43:25 GMT+0530 (India Standard Time)",
        cardExpiryDate: "Sun May 19 2019 15:43:25 GMT+0530 (India Standard Time)"
      }
    ];

    const user = {
      email: "knowledge.com2k16@gmail.com"
    };

    expect(mount(<GiftsSendTableContainer 
    isLoggedIn = {true}
    user={user}
    sentCards={data}
    fetchSentCards={jest.fn()}
    />
    ).html()).toMatchSnapshot();
  });

  it("should fetch sent cards", () => {
    let dispatch = jest.fn();

    let props = mapDispatchToProps(dispatch);
    props.fetchSentCards("knowledge.com2k16@gmail.com", 100, 1);

    expect(dispatch).toHaveBeenCalled();
    expect(dispatch).toHaveBeenCalledTimes(1);
  });
});
import React, { useEffect, useState } from "react";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import { InfiniteLoader, Table, Column } from "react-virtualized";
import 'react-virtualized/styles.css'

import { fetchFilteredReceivedCards } from '../state/actions/index';

const mapStateToProps = ({ 
  users: { cards } }) => {
    return {
      receivedCards: cards
    };
};

export const mapDispatchToProps = dispatch => {
  return bindActionCreators({
    fetchFilteredReceivedCards
  },
  dispatch);
}

const rowLimit = 100;

export const GiftsReceivedTableContainer = ({
  receivedCards,
  fetchFilteredReceivedCards
}) => {
const [page, setPage] = useState(1);

useEffect(() => {
  fetchFilteredReceivedCards("lovelysen020@gmail.com", rowLimit, page);
  setPage(page + 1);
}, []);

const isRowLoaded = ({ index }) => index < receivedCards.length
const loadMoreRows = () => {
  fetchFilteredReceivedCards("lovelysen020@gmail.com", rowLimit, page);
  setPage(page + 1);
};
const rowGetter = ({ index }) => receivedCards[index]

return(
  <div>
    <InfiniteLoader
      isRowLoaded={isRowLoaded}
      rowCount={receivedCards.length + 1}
      loadMoreRows={loadMoreRows}
    >
      {({ onRowsRendered, registerChild }) => (
        <Table
          ref={registerChild}
          rowCount={receivedCards.length}
          rowGetter={rowGetter}
          rowHeight={40}
          headerHeight={50}
          overscanRowCount={1}
          width={1200}
          height={490}
          onRowsRendered={onRowsRendered}
          // rowRenderer={getRowRenderer}
          // rowClassName="test__event_table_row"
        >
          <Column dataKey="id" width={200} label="ID" />
          <Column dataKey="cardName" width={200} label="CARD NAME" />
          <Column dataKey="cardPoints" width={200} label="POINTS" />
          <Column dataKey="senderEmail" width={200} label="RECEIVED FROM" />
          <Column dataKey="cardIssueDate" width={200} label="ISSUE DATE" />
          <Column dataKey="cardExpiryDate" width={200} label="EXPIRY DATE" />
        </Table>
      )}
    </InfiniteLoader>
  </div>
);
}

GiftsReceivedTableContainer.propTypes = {
  receivedCards: PropTypes.array.isRequired,
  fetchFilteredReceivedCards: PropTypes.func.isRequired
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(GiftsReceivedTableContainer);

import React, { useEffect, useState } from "react";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import { InfiniteLoader, Table, Column } from "react-virtualized";
import 'react-virtualized/styles.css'

import { fetchSentCards, redeemCard } from '../state/actions/index';

const mapStateToProps = (state) => {
    return {
        user:state.login.detailsObject,
        isLoggedIn: state.login.loginStatus,
        sentCards: state.users.cards
    }
}

export const mapDispatchToProps = dispatch => {
  return bindActionCreators({
    fetchSentCards
  },
  dispatch);
}

const rowLimit = 100;

export const GiftsSendTableContainer = ({
    sentCards,
  fetchSentCards
}) => {
const [page, setPage] = useState(1);

useEffect(() => {
    fetchSentCards("lovelysen020@gmail.com", rowLimit, page);
  setPage(page + 1);
}, []);

const isRowLoaded = ({ index }) => index < sentCards.length
const loadMoreRows = () => {
    fetchSentCards("lovelysen020@gmail.com", rowLimit, page);
  setPage(page + 1);
};
const rowGetter = ({ index }) => sentCards[index]

return(
  <div>
    <InfiniteLoader
      isRowLoaded={isRowLoaded}
      rowCount={sentCards.length + 1}
      loadMoreRows={loadMoreRows}
    >
      {({ onRowsRendered, registerChild }) => (
        <Table
          ref={registerChild}
          rowCount={sentCards.length}
          rowGetter={rowGetter}
          rowHeight={40}
          headerHeight={50}
          overscanRowCount={1}
          width={1200}
          height={490}
          onRowsRendered={onRowsRendered}
         
          
        >
          <Column dataKey="id" width={200} label="ID" />
          <Column dataKey="cardName" width={200} label="CARD NAME" />
          <Column dataKey="cardPoints" width={200} label="POINTS" />
          <Column dataKey="receiverEmail" width={200} label="SENT TO" />
          <Column dataKey="cardIssueDate" width={200} label="ISSUE DATE" />
          <Column dataKey="cardExpiryDate" width={200} label="EXPIRY DATE" />
        </Table>
      )}
    </InfiniteLoader>
  </div>
);
}

GiftsSendTableContainer.propTypes = {
    sentCards: PropTypes.array.isRequired,
    fetchSentCards: PropTypes.func.isRequired
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(GiftsSendTableContainer);

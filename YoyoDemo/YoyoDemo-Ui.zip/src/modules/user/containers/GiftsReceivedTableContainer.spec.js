import React from "react";
import { mount } from "enzyme";

import { GiftsReceivedTableContainer, mapDispatchToProps } from "./GiftsReceivedTableContainer";

describe("Gifts Sent Table Test Suite", () => {


  it('table with header and data', () => {
    //Mocks
    const data = [
        {
          cardName: 'amazon',
          cardPoints: 100,
          senderEmail: 'amazon@gmail.com',
          cardIssueDate: "Sun May 19 2019 15:43:25 GMT+0530 (India Standard Time)",
          cardExpiryDate: "Sun May 19 2019 15:43:25 GMT+0530 (India Standard Time)"
        },
        {
          cardName: 'test1',
          cardPoints: 2,
          senderEmail: 'amazon@gmail.com',
          cardIssueDate: "Sun May 19 2019 15:43:25 GMT+0530 (India Standard Time)",
          cardExpiryDate: "Sun May 19 2019 15:43:25 GMT+0530 (India Standard Time)"
        },
        {
          cardName: 'test2',
          cardPoints: 3,
          senderEmail: 'amazon@gmail.com',
          cardIssueDate: "Sun May 19 2019 15:43:25 GMT+0530 (India Standard Time)",
          cardExpiryDate: "Sun May 19 2019 15:43:25 GMT+0530 (India Standard Time)"
        }
    ];

    const user = {
      email: "amazon@gmail.com"
    };

    const wrapper = mount(<GiftsReceivedTableContainer 
    isLoggedIn = {true}
    receivedCards={data}
    user={user}
    fetchFilteredReceivedCards={jest.fn()}
    />);
    
    expect(wrapper.find('div').length).toBe(32);
  });

  it('should render the expected HTML', () => {
    expect(mount(<GiftsReceivedTableContainer 
    isLoggedIn = {true}
    receivedCards={[]}
    fetchFilteredReceivedCards={jest.fn()}
    />
    ).html()).toMatchSnapshot();
  });

  it('should render the expected HTML', () => {
    //Mocks
    const data = [
        {
          cardName: 'amazon',
          cardPoints: 1,
          senderEmail: 'amazon@gmail.com',
          cardIssueDate: "Sun May 19 2019 15:43:25 GMT+0530 (India Standard Time)",
          cardExpiryDate: "Sun May 19 2019 15:43:25 GMT+0530 (India Standard Time)"
        },
        {
          cardName: 'test1',
          cardPoints: 2,
          senderEmail: 'amazon@gmail.com',
          cardIssueDate: "Sun May 19 2019 15:43:25 GMT+0530 (India Standard Time)",
          cardExpiryDate: "Sun May 19 2019 15:43:25 GMT+0530 (India Standard Time)"
        },
        {
          cardName: 'test2',
          cardPoints: 3,
          senderEmail: 'amazon@gmail.com',
          cardIssueDate: "Sun May 19 2019 15:43:25 GMT+0530 (India Standard Time)",
          cardExpiryDate: "Sun May 19 2019 15:43:25 GMT+0530 (India Standard Time)"
        }
    ];

    const user = {
      email: "amazon@gmail.com"
    };

    expect(mount(<GiftsReceivedTableContainer 
    isLoggedIn = {true}
    user={user}
    receivedCards={data}
    fetchFilteredReceivedCards={jest.fn()}
    />
    ).html()).toMatchSnapshot();
  });

  it("should fetch sent cards", () => {
    let dispatch = jest.fn();

    let props = mapDispatchToProps(dispatch);
    props.fetchFilteredReceivedCards("amazon@gmail.com", 100, 1);

    expect(dispatch).toHaveBeenCalled();
    expect(dispatch).toHaveBeenCalledTimes(1);
  });
});
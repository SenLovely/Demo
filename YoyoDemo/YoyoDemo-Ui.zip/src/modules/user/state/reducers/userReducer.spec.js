import usersReducer from "./usersReducer";
import { RECEIVED_CARDS, SENT_CARDS, USER_DETAILS, REDEEM_CARD, UPDATE_BALANCE, UPDATE_TRANSACT } from '../actions/types';

describe("Gift Reducer Test Suite", () => {
  it("should be initial state", () => {
    expect(usersReducer(undefined, {})).toEqual(
    {
        cards: [],
        UserDetails: []
    });
  });
  
   
  it("should SENT_CARDS work and the data", () => {
    const prevState = {
        cards: [],
    };
    const cardData = {
        balance_points: 1500
    };

    let action = {
        type: SENT_CARDS,
        payload:cardData
        
    };
 

    expect(usersReducer(prevState, action)).toEqual(
    {
        cards: cardData
    });
});

// it("should ADMIN_UPDATE_CARD give updated data", () => {
//     const prevState = {
//         giftCard: {}
//     };
//     const cardData = {
//         cardCount: 10
//     };

//     let action = {
//         type: ADMIN_UPDATE_CARD,
//         payload: {
//             data: cardData
//         }
//     };

//     expect(usersReducer(prevState, action)).toEqual(
//     {
//         cards: cardData
//     });
// });

});
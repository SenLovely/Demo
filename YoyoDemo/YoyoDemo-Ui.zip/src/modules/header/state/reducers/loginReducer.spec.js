import loginReducer from "./loginReducer";

import { LOGIN, LOGOUT } from "../actions/types";

describe("Login Reducer Test Suite", () => {
  it("should give initial state", () => {
    expect(loginReducer(undefined, {})).toEqual(
    {
      loginStatus: false,
      detailsObject: {}
    });
  });
  
  it("should login the user and add details", () => {
    const prevState = {
      loginStatus: false,
      detailsObject: {}
    };
    const userData = {
      id: 1,
      firstName: "lovely",
      lastName: "sen",
      email: "lovelysen.@gmail.com"
    };

 
    let action = {
        type: LOGIN,
        payload: userData
    };

    expect(loginReducer(prevState, action)).toEqual(
    {
      loginStatus: true,
      detailsObject: userData
    });
  });

  it("should logout and empty it", () => {
    const prevState = {
      loginStatus: true,
      detailsObject: {
        id: 1,
      firstName: "lovely",
      lastName: "sen",
      email: "lovelysen.@gmail.com"
      }
    };
   
    let action = {
        type: LOGOUT,
        payload: {}
    };

    expect(loginReducer(prevState, action)).toEqual(
    {
      loginStatus: false,
      detailsObject: {}
    });
  });
});
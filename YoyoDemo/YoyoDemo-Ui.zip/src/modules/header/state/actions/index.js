import { LOGIN, LOGOUT } from "./types";
import axiosWrapper from "../../../../apis/axiosCreate";
// export const login = (LoginInfo) => async (dispatch) => {
//   //export const login = async (LoginInfo) => {
//   console.log("response LoginInfo",LoginInfo);
//   //const response = await axiosWrapper.get(`/users?email=${LoginInfo}`);
//   //console.log("response login",response);
//   // if(response.data.length>0)
//   // dispatch ({
//   //   type: LOGIN,
//   //   payload: "lathak95@gmail.com"
//   // })
//   // else{
//   //   const newUser = {
//   //      //"first_name":LoginInfo.name.split("")[0],
//   //      //"last_name":LoginInfo.name.split("")[1],
//   //      //"email":LoginInfo.email,
//   //      //"balance_points":Math.ceil(Math.random()=10000)


      
//   //     }
//   //     createUser(newUser);
//   // }
// };
export const login = Object => async(dispatch)=>{
  console.log("response LoginInfo",Object);
  dispatch( {
    type: LOGIN,
    payload: Object
  })
  //const user = JSON.parse(window.sessionStorage.settItem("user"))
}

export const logout = () => async(dispatch)=>{
  dispatch( {
    type: LOGOUT,
    payload: {}
  })
}

export const createUser = userDetails => async dispatch => {
  console.log("test create user",userDetails);

  await axiosWrapper.post(`/users`, userDetails);
};

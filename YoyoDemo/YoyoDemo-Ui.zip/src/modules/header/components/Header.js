import React, { Component } from "react";
import PropTypes from "prop-types";
import { withStyles } from "@material-ui/core/styles";
import AppBar from "@material-ui/core/AppBar";
import Toolbar from "@material-ui/core/Toolbar";
import Typography from "@material-ui/core/Typography";
import Button from "@material-ui/core/Button";
import { connect } from "react-redux";
import { login, logout, createUser } from "../state/actions";
import { bindActionCreators } from "redux";
import history from "../../common/components/history";
import MySnackBar from "../../common/components/Snackbar";
import Styles from '../../../assets/css/Header.module.css';
import { GoogleLogin, GoogleLogout } from 'react-google-login';
import axiosWrapper from "../../../apis/axiosCreate";


const styles = {
  root: {
    flexGrow: 1,
    flexShrink: 1,
    width: '100%' 
  },
  grow: {
    flexGrow: 1
  },
  toolBar: {
    background: "#32567e"
  }
};

export class Header extends Component {
  constructor(props){
    super(props)
    this.state = {
      showErrorSnack: false,
      id: 0,
    first_name: "",
    last_name: "",
    email: "",
    balance_points: 0,
    islog:false
    }
  }
  render() {
    const { showErrorSnack } = this.state
    const { classes } = this.props;
    return (
      <div className={classes.root}>
        {
          showErrorSnack ? 
          <MySnackBar message='Network Error! Please try again' color='red' />
          :
          null
        }
        <AppBar position="static">
          <Toolbar className={classes.toolBar}>
            <Typography variant="h6" color="inherit" className={classes.grow}>
              <Button onClick={this.goTolanding}>
                <span style={{ fontSize: "1.2em", color: "#ffffff" }}>
                  YOYOGift
                </span>
              </Button>
            </Typography>
            {/* {this.props.isLoggedIn ? <Button color="inherit" onClick={this.addUpdateForm}>ADD UPDATE FORM</Button> : null} */}
            {this.props.isLoggedIn ? (
              <Button className={Styles.headerButton} color="inherit" onClick={this.giftsReceived}>
                GIFTS RECEIVED
              </Button>
            ) : null}
            {this.props.isLoggedIn ? (
              <Button className={Styles.headerButton} color="inherit" onClick={this.giftsSend}>
                GIFTS SENT
              </Button>
            ) : null}
            {this.props.isLoggedIn ? (
              <Button className={Styles.headerButton} color="inherit" onClick={this.myProfile}>
                MY PROFILE
              </Button>
            ) : null}
            <Button className={Styles.headerButton}
              color="inherit"
              onClick={() => {}}
            >
              {this.props.isLoggedIn ? 
              <GoogleLogout
                clientId="228935478905-lrnl1u77c007jhtnevha0a6jl1vctsm4.apps.googleusercontent.com"
                buttonText="Logout"
                onLogoutSuccess={this.logOut}
              />
              :
              <GoogleLogin
                clientId="228935478905-lrnl1u77c007jhtnevha0a6jl1vctsm4.apps.googleusercontent.com"
                buttonText="Login"
                onSuccess={this.responseSuccess}
                onFailure={this.responseSuccess}
                cookiePolicy={'single_host_origin'}
              />
              }
            </Button>
          {}  
          </Toolbar>
        </AppBar>
      </div>
    );
  }

  responseSuccess = async(response) => {
  
    const { profileObj: { googleId, email, familyName, givenName } } = response;
   
    const userInMemory =  await axiosWrapper.get(`/users?email=${email}`);
    const { data } = userInMemory;
 
    if(data.length === 0) {
      
      const newUser = {
        id: googleId,
        first_name: givenName,
        last_name: familyName,
        email: email,
        balance_points: 2000
      }
     
      this.props.createUser(newUser)
    }
    else { 
     
      var userData = data[0];
    
     this.setState=({
    
        id: userData.id,
        first_name: userData.first_name,
        last_name: userData.last_name,
        email: userData.email,
        balance_points: userData.balance_points
      });
     
      this.props.login(userData);
      debugger;
      window.sessionStorage.setItem("user",JSON.stringify(userData));
     
    }
  };

  goTolanding = () => {
    history.push("/");
  };
  myProfile = () => {
    history.push("/Profile");
  };
  // loginpage = (x) => {
   
  //   this.setState=({islog:x});
  //    console.log("islog",this.state.islog,x)
  // //  if (this.state.islog === true)
  // //   {
  // //     this.props.logout()
  // //   }    
  // //   else{
  // //     this.props.logout()
  // //   }
  // };
  giftsSend = () => {
    history.push("/GiftsSend");
  };

  giftsReceived = () => {
    history.push("/GiftsReceived");
  };

  logOut = () => {
    this.props.logout();
    history.push("/");
    window.sessionStorage.removeItem("user");
    window.sessionStorage.removeItem("usertype");
  };

}

Header.propTypes = {
  classes: PropTypes.object.isRequired
};

const mapStateToProps = state => {
  return {
    isLoggedIn: state.login.loginStatus,
    userDetails: state.login.detailsObject
  };
};

export const mapDispatchToProps = dispatch => {
  return bindActionCreators({ login, logout, createUser }, dispatch);
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withStyles(styles)(Header));

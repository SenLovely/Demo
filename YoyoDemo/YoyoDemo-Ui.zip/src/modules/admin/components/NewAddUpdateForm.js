
import React, { Component } from "react";

import { withRouter } from "react-router-dom";
import { Button } from "@material-ui/core";
import { connect } from "react-redux";
import { adminAddCard, adminUpdateCard, fetchCard } from "../../gifts/state/actions/index";
import history from "../../common/components/history";
import { bindActionCreators } from "redux";
import { Formik, Form, Field } from "formik";
import * as yup from "yup";
export class NewAddUpdateForm extends Component {
  constructor(props) {
    super(props);
    this.state = {
      paramId: '',
    }
  }

  componentDidMount() {

    const id = +this.props.match.params.id;
    this.setState({ paramId: id });
    this.props.fetchCard(id);
console.log("check expiry date", new Date(this.props.giftCard.cardExpiryDate));

  }
  render() {
    const initialValues = {
      cardNameValue: this.props.giftCard ? this.props.giftCard.cardName : "",

      cardPointsValue: this.props.giftCard ? this.props.giftCard.cardPoints : "",

      cardCategoryValue: this.props.giftCard ? this.props.giftCard.cardCategory : "",

      cardRetailerValue: this.props.giftCard ? this.props.giftCard.cardRetailer : "",

      cardExpiryDateValue: this.props.giftCard ? this.props.giftCard.cardExpiryDate: "",

      cardCountValue: this.props.giftCard ? this.props.giftCard.cardCount : "",

      cardImageValue: this.props.giftCard ? this.props.giftCard.cardImage : "",

      cardVendorValue: this.props.giftCard ? this.props.giftCard.cardVendor : "",

      cardShortDescValue: this.props.giftCard ? this.props.giftCard.cardShortDesc : "",

      cardLongDescValue: this.props.giftCard ? this.props.giftCard.cardLongDesc : "",
    };
    const SignInSchema = yup.object().shape({
      cardNameValue: yup
        .string()
        .matches(/^[A-Za-z\s]+$/, "Please enter valid card name")
        .max(100)
        .required("card name is required"),
      cardPointsValue: yup
        .string()
        .matches(/^[0-9]+$/, "Only whole numbers are accepted")
        .max(100)
        .required("card points is required"),
      cardCategoryValue: yup
        .string()
        .matches(
          /^[A-Za-z\s]+$/,
          "Only alphabets of max length 100 are accepted"
        )
        .max(100)
        .required("card category is required"),
      cardRetailerValue: yup
        .string()
        .matches(
          /^[A-Za-z\s]+$/,
          "Only alphabets of max length 100 are accepted"
        )
        .max(100)
        .required("card retailer is required"),

        // cardExpiryDateValue: yup
        // .date()
        // .required("Expiry Date is required!"),
        // .min(new Date(), "Expiry Date should be greater than today!"),

      //   issueDate: yup
      // .date()
      // .required(),
      // cardExpiryDateValue: yup
      // .date()
      // .when(
      //   'issueDate',
      //   (issueDate, schema) => (issueDate && schema.min(issueDate, 'Expiry date must be greater than issue date')),
      // ),
      // cardExpiryDateValue: yup
      //   .date()        
      //   .required("Expiration date is required"),
      
      cardCountValue: yup
        .string()
        .matches(/^[0-9]+$/, "Only whole numbers are accepted")
        .max(100)
        .required("card count is required"),
      cardImageValue: yup
        .string()
        .matches(
          /(http(s?):)([/|.|\w|\s|-])*\.(?:jpg|gif|png)/,
          "Only valid image links of max length 10000 are accepted"
        )
        .max(100)
        .required("image link is required"),
      cardVendorValue: yup
        .string()
        .matches(
          /^[A-Za-z\s]+$/,
          "Only alphabets of max length 100 are accepted"
        )
        .max(100)
        .required("vendor is required"),
      cardShortDescValue: yup
        .string()
        .required("short description is required"),
      cardLongDescValue: yup
        .string()
        .required("long name is required"),
    });
    const onSubmit = (values) => {

      //alert(JSON.stringify(values, null, 2));
      let cardExpiryDateValue = new Date(values.cardExpiryDateValue);
      this.cardObject = {
        id: Math.floor(Math.random() * 100 + 1),
        cardName: values.cardNameValue,
        cardPoints: values.cardPointsValue,
        cardCategory: values.cardCategoryValue,
        cardRetailer: values.cardRetailerValue,
        cardIssueDate: new Date(),
        cardExpiryDate: cardExpiryDateValue,
        cardCount: values.cardCountValue,
        cardImage: values.cardImageValue,
        cardVendor: values.cardVendorValue,
        cardShortDesc: values.cardShortDescValue,
        cardLongDesc: values.cardLongDescValue,
        cardComments: [],
      }
      if (!this.props.match.params.id) {
        let cardExpiryDateValue = new Date(values.cardExpiryDateValue);
        this.cardObject = {
          id: Math.floor(Math.random() * 100 + 1),
          cardName: values.cardNameValue,
          cardPoints: values.cardPointsValue,
          cardCategory: values.cardCategoryValue,
          cardRetailer: values.cardRetailerValue,
          cardIssueDate: new Date(),
          cardExpiryDate: cardExpiryDateValue,
          cardCount: values.cardCountValue,
          cardImage: values.cardImageValue,
          cardVendor: values.cardVendorValue,
          cardShortDesc: values.cardShortDescValue,
          cardLongDesc: values.cardLongDescValue,
          cardComments: [],
        };
        this.props.adminAddCard(this.cardObject).then(() => {
          this.setState({
            showSuccessSnackBar: true,
          });
          setTimeout(() => {
            this.setState({
              showSuccessSnackBar: false,
            });
            history.push("/giftCards");
          }, 2000);
        });
      } else if (Object.keys(this.cardObject).length !== 0) {

        this.props
          .adminUpdateCard(this.state.paramId, this.cardObject)
          .then((response) => {
            this.setState({
              showUpdateSnackBar: true,
            });
            setTimeout(() => {
              this.setState({
                showUpdateSnackBar: false,
              });
              history.push("/giftCards");
            }, 2000);
          });
      }
    };

    return (
      <>
        <div
          style={{
            display: "flex",
            flexDirection: "column",
            alignItems: "left",
            width: "100%",
          }}
        >
          <Formik
            initialValues={initialValues}
            enableReinitialize={true}
            validationSchema={SignInSchema}
            onSubmit={onSubmit}
          >
            {({ isSubmitting, errors, touched }) => (
              <Form>

                <div
                  style={{
                    display: "flex",
                    marginRight: "8%",
                    width: "20%",
                    flexDirection: "column",
                    justifyContent: "space-between",
                  }}
                >
                  <label htmlFor="cardNameValue">Card Name</label>
                  <Field
                    name="cardNameValue"
                    placeholder="Card Name"
                    type="text"
                  />
                  {errors.cardNameValue && touched.cardNameValue ? (
                    <div className="styleError">{errors.cardNameValue}</div>
                  ) : null}
                  <label htmlFor="cardPointsValue">Card Points</label>
                  <Field
                    name="cardPointsValue"
                    placeholder="Card Points"
                    type="text"
                  />
                  {errors.cardPointsValue && touched.cardPointsValue ? (
                    <div>{errors.cardPointsValue}</div>
                  ) : null}
                  <label htmlFor="cardCategoryValue">Card Category</label>
                  <Field
                    name="cardCategoryValue"
                    placeholder="Card Category"
                    type="text"
                  />
                  {errors.cardCategoryValue && touched.cardCategoryValue ? (
                    <div>{errors.cardCategoryValue}</div>
                  ) : null}
                  <label htmlFor="cardRetailerValue">Card Retailer</label>
                  <Field
                    name="cardRetailerValue"
                    placeholder="Card Retailer"
                    type="text"
                  />
                  {errors.cardRetailerValue && touched.cardRetailerValue ? (
                    <div>{errors.cardRetailerValue}</div>
                  ) : null}
                  <label htmlFor="cardExpiryDateValue">Card Expiry Date</label>
                  <Field
                    name="cardExpiryDateValue"
                    placeholder=""
                    type="date"
                  />
                  {errors.cardExpiryDateValue && touched.cardExpiryDateValue ? (
                    <div>{errors.cardExpiryDateValue}</div>
                  ) : null}
                  <label htmlFor="cardCountValue">Card Count</label>
                  <Field name="cardCountValue" placeholder="" type="text" />
                  {errors.cardCountValue && touched.cardCountValue ? (
                    <div>{errors.cardCountValue}</div>
                  ) : null}
                  <label htmlFor="cardImageValue">Card Image</label>
                  <Field name="cardImageValue" placeholder="" type="text" />
                  {errors.cardImageValue && touched.cardImageValue ? (
                    <div>{errors.cardImageValue}</div>
                  ) : null}
                  <label htmlFor="cardVendorValue">Card Vendor</label>
                  <Field name="cardVendorValue" placeholder="" type="text" />
                  {errors.cardVendorValue && touched.cardVendorValue ? (
                    <div>{errors.cardVendorValue}</div>
                  ) : null}
                  <label htmlFor="cardShortDescValue">Short Description</label>
                  <Field name="cardShortDescValue" placeholder="" type="text" />
                  {errors.cardShortDescValue && touched.cardShortDescValue ? (
                    <div>{errors.cardShortDescValue}</div>
                  ) : null}
                  <label htmlFor="cardLongDescValue">Long Image</label>
                  <Field name="cardLongDescValue" placeholder="" type="text" />
                  {errors.cardLongDescValue && touched.cardLongDescValue ? (
                    <div>{errors.cardLongDescValue}</div>
                  ) : null}
                  <div
                    className="action_btn_w"
                    style={{
                      paddingBottom: "12px",
                      marginTop: "12px",
                      borderTop: "1px solid rgb(229 229 229",
                    }}
                  >

                    <button
                      className="actionBtn0"
                      id="btnSubmit"
                      type="submit"
                      disabled={isSubmitting}
                    >
                      {this.props.giftCard && this.props.giftCard.id ? "Update" : "save"}


                    </button>
                  </div>
                </div>
              </Form>
            )}
          </Formik>
        </div>
      </>
    );
  }
}
export const mapDispatchToProps = dispatch => {
  return bindActionCreators({
    fetchCard,
    adminAddCard, 
    adminUpdateCard
  },
  dispatch
  );
}//lovely test

const mapStateToProps = (state) => {
  return {
    giftCard: state.gifts.giftCard,
  };
};

// export default connect(mapStateToProps, { fetchCard, adminAddCard, adminUpdateCard })(
//   withRouter(NewAddUpdateForm)
// );
export default connect (
  mapStateToProps,
  mapDispatchToProps
)(NewAddUpdateForm);

import React from 'react';
import { shallow } from 'enzyme';
import Footer from './Footer.js';

describe('Footer Component', () => {
    it('should render Footer component', () => {
        const wrapper = shallow(<Footer />)
        expect(wrapper.exists()).toBe(true);
    });
});
import React from 'react';
import { shallow } from 'enzyme';
import GiftCard from './GiftCard.js';

describe('GiftCard Component', () => {
    it('should render GiftCard component', () => {
        const wrapper = shallow(<GiftCard />)
        expect(wrapper.exists()).toBe(true);
    });
});

